#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <windows.h>
#include <conio.h>
#include<cstdlib>
using namespace std;


int Manager_max = 0;

int Worker_max = 0;

class Designing
{
private:
	char x;
public:
	void SetConsoleColor(int color)
	{
		HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleTextAttribute(hConsole, color);
	}

	void Style()
	{
		SetConsoleColor(11); 
		cout << "\t\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\a";
		cout << "\t\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
		cout << "\t\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
		cout << "\t\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
		cout << "\t\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
		cout << "\t\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\a";
		SetConsoleColor(5);
		
		cout << " \t\t**********    *******             ******   ***************       ***              ***********             "<<endl;
		cout << " \t\t**********    ********           *******   *****************     ***            ***************           "<<endl;
		cout << " \t\t**********    *********         ********   ******************    ***           ****         ****          "<<endl;
		cout << " \t\t***           ***    ***       ***   ***   ***            ****   ***          ****           ****   ***   "<<endl;
		cout << " \t\t***           ***     ***     ***    ***   *****************     ***          ***             ***   ***   "<<endl;
		cout << " \t\t*******       ***      ***   ***     ***   ****************      ***          ***             ***         "<<endl;
     	cout << " \t\t*******       ***       *** ***      ***   ***************       ***          ***             ***   ***   "<<endl;
		cout << " \t\t*******       ***        *****       ***   ***                   ***          ***             ***   ***   "<<endl;
		cout << " \t\t***           ***                    ***   ***                   ***          ***             ***   ***   "<< endl;
		cout << " \t\t***           ***                    ***   ***                   ***          ***             ***   ***   "<< endl;
		cout << " \t\t**********    ***                    ***   ***                   **********    ***           ***    ***   "<< endl;
		cout << " \t\t**********    ***                    ***   ***                   **********     ***************     ***   "<< endl;
		cout << " \t\t**********    ***                    ***   ***                   **********       ***********       ***   "<< endl;
		
		SetConsoleColor(11);
		cout << "\t\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
		cout << "\t\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
		cout << "\t\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
		cout << "\t\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
		cout << "\t\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
		cout << "\t\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
		Sleep(2000);
		system("cls");
	}
	void Loading_Style()
	{
		x = 219;
		for (int i = 0; i < 20; i++)
		{
			cout << x;
			Sleep(100);
		}
	}

};
Designing Desig;

class Store_List
{
	public:
		void Put_Manager_list()
		{
			ifstream Manager_m("Manager_ma.txt", ios::in);
		
			Manager_m>>Manager_max;
	
			Manager_m.close();
		}

		void Put_Worker_list()
		{
			ifstream Worker_m("Worker_ma.txt", ios::in);
	
			Worker_m>>Worker_max;
	
			Worker_m.close();	
		}
	
		void Get_Manager_list()
		{
			ofstream Manager_M("Manager_ma.txt", ios::out);
	
			Manager_M<<Manager_max;
	
			Manager_M.close();
		}
	
		void Get_Worker_list()
		{
			ofstream Worker_W("Worker_ma.txt" , ios::out);
	
			Worker_W<<Worker_max;
	
			Worker_W.close();
		}
};
	
class login_try:public Designing
{
	private:
		bool attempt;
		string username;
		long password;
	public:
		login_try()
			{

				username="";
				password=0;
				attempt=false;
			}
		void login_attempt()
			{
				log:
				Desig.Style();
				SetConsoleColor(11);
                cout<<"\a LOADING DATA";
                for (int i = 0; i <= 8; i++)
	{
		SetConsoleColor(11);
		cout << ".";
		Sleep(1000);
	}
	system("CLS");
	SetConsoleColor(8);
	cout << " \t\t\t\t\t\a Logged in successfully ! " << endl;
	Sleep(1000);
	system("CLS");
                SetConsoleColor(7);
				cout<<"\t\t\t\t\tusername : ";
				getline(cin,username);

				cout<<"\t\t\t\t\tpassword : ";
				cin>>password;

					if (username=="handlemyemploi" && password == 9111122)
						{
							system("cls");
							    cin.ignore();
						}
					else  if(username=="handlemyemploi"&& password !=9111122)
						{
							system("cls");
							SetConsoleColor(12);
							cout<<"\n\n\t\t\t\t\a\a\a Wrong password !"<<endl;
							cin.ignore();
							goto log;
						}
					else if(username!="handlemyemploi" && password == 9111122)
						{
							system("cls");
							
							cout<<"\n\n\t\t\t\t\a\a Please enter the corect username !"<<endl;
							cin.ignore();
							goto log;
						}
					else
						{
							system("cls");
						    
							cout<<"\n\n\t\t\t\t\a\ayour login attempt fail"<<endl;
							cout<<"\n\n\t\t\t\t\a\aenter correct data"<<endl;
							cin.ignore();
							goto log;
						}	
						SetConsoleColor(7);
			}
			
};

class EMPLOYEE
{
	protected:
		string First_name, Last_name;
		int age;
		double House_no;
		string Block, Town, City, Province;
		string CNIC, Phone_no, Emergency_no, Email;
		int joining_year;
		int joining_month;
		int joining_date;
		long Salary_per_day;
	
		char Current_Char;
	
	public:
			
		void Personal_Info()
			{
				
				cout<<"\t\t\t\tPERSONAL INFORMATON"<<endl;
				
				cout<<"\n\t\t\t\t\tFirst NAME : ";
				getline(cin, First_name);
			
				cout<<"\t\t\t\t\tLast Name : ";
				getline(cin, Last_name);
				age:
				cout<<"\t\t\t\t\tAge : ";
				cin>>age;
				if(age>=65)
				    {
						cout<<"\t\t\t\t\tOVER AGE"<<endl;
						goto age;
					}
				else if (age<18)
					{
					
						cout<<"\t\t\t\t\tUNDER AGE"<<endl;
						goto age;
					}
				cin.ignore();
		
				cnic:
				int count2=0;
				cout<<"\t\t\t\t\tCNIC (without dashes) : ";
				cin>>CNIC;
				if (CNIC.length()!=13)
					{
						cout<<"\t\t\t\t\tInvalid entry"<<endl;
						goto cnic;
					}
				for(int i=0; i<CNIC.length(); i++)
					{
						Current_Char=CNIC.at(i);
						if(!isdigit(Current_Char))
							{
								cout<<"\t\t\t\t\tInvalid entry"<<endl;
								goto cnic;
							}
					}
				cin.ignore();
			}
		
		void Address()
			{
				cout<<"\t\t\t\tPERSONAL INFORMATON"<<endl;
				cout<<"\n\t\t\t\t\t House No : ";
				cin>>House_no;
			
				cout<<"\t\t\t\t\t Block : ";
				cin>>Block;
	
				cout<<"\t\t\t\t\t Town : ";
				cin>>Town;
				
				cout<<"\t\t\t\t\t City : ";
				cin>>City;
	
				cout<<"\t\t\t\t\t Province : ";
				cin>>Province;
			}	
			
		void Contact_Info()
			{
	
				cout<<"\n\n\t\t\t\tCONTACT INFORMATION"<<endl; 
	
				P_n:
					
				cout<<"\t\t\t\t\tPhone_no  : +92";
				cin>>Phone_no;
				if (Phone_no.length()!=10)
					{
						
						cout<<"\t\t\t\t\tInvalid entry"<<endl;
						goto P_n;
					}
				for(int i=0; i<Phone_no.length(); i++)
					{
						Current_Char=Phone_no.at(i);
							if(!isdigit(Current_Char))
								{
				
									cout<<"\t\t\t\t\tInvalid entry"<<endl;
									goto P_n;	
								}
					}
	
				E_n:
				int cou=0;
			
				cout<<"\t\t\t\t\tEmergency No  : +92";
				cin>>Emergency_no;
					if (Emergency_no.length()!=10)
						{
						
							cout<<"\t\t\t\t\tInvalid entry"<<endl;
							goto E_n;
						}
					for(int i=0; i<Emergency_no.length(); i++)
						{
							Current_Char=Emergency_no.at(i);
								if(!isdigit(Current_Char))
									{
				
										cout<<"\t\t\t\t\tInvalid entry"<<endl;
										goto E_n;
									}
						}
	
	
				Em:

				cout<<"\t\t\t\t\tPersonal Email :";
				cin>>Email;
					if((Email.at(0)>= 'a' && Email.at(0) <= 'z') || (Email.at(0) >= 'A' && Email.at(0)<= 'Z'))
						{
		
						}
					else
						{
			
							cout<<"\t\t\t\t\tINVALID EMAIL";
							goto Em;	
						}
			}
			
		void Date_Join()
			{

				cout<<"\t\t\t\t  DATE OF JOINING \n"<<endl;
			
				Da:

				cout<<"\t\t\t\t\tDATE (1 to 31) : ";
				cin>>joining_date;
					if (joining_date>30 || joining_date<1)
						{
						
							cout<<"\t\t\t\t\tINVALID ENTRY";
							goto Da;
						}
			
				Mo:
	
				cout<<"\t\t\t\t\tMONTH (1 to 12) : ";
				cin>>joining_month;
					if (joining_month>12 || joining_month<1)
						{
			
							cout<<"\t\t\t\t\tINVALID ENTRY";
							goto Mo;
						}
						
				Ye:
				cout<<"\t\t\t\t\tYear (2010 to 2022) : ";
				cin>>joining_year;
					if (joining_year>2022 || joining_year<2010)
						{
					
							cout<<"\t\t\t\t\tINVALID ENTRY";
							goto Ye;
						} 
			}
			
		virtual void Edit() = 0;
};

class Finance
{
	protected:
		int Loan_Months;
		string Loan_Type;
		double Total_Loan=0;
		double Loan_Deduction = 0;
		double Advance = 0;
		double HR_Charges;
		double Bonus;
		double Total_Salary;
		double Day_Attended;
		string HR_Number;
		int Selection;
	public:
		void Loan_Facility()
		{
			if (Total_Loan==0)
			{
				system("cls");
				Ser:
				Desig.Style();
				
				cout<<"\n\n\t\t\t\t\tEnter which type of loan you want to take "<<endl;
				
				cout<<"\t\t\t\t\t1. Home Loan "<<endl;
			
				cout<<"\t\t\t\t\t2. Vehical Loan "<<endl;
		
				cout<<"\t\t\t\t\t3. Personal Loan "<<endl;
				cin>>Selection;
					if(Selection == 1)
						{
							Loan_Type=="Home_Loan";
						}
					else if(Selection == 2)
						{
							Loan_Type=="Vehical_Loan";
						}
					else if(Selection == 3)
						{
							Loan_Type=="Personal_Loan";
						}
					else
						{
							cout<<"Invalid Selection";
							goto Ser;
						}
		
				cout<<"\n\t\t\t\t\tLoan Amount : ";
				cin>>Total_Loan;
			
				cout<<"\t\t\t\t\tFor How many Months : ";
				cin>>Loan_Months;
				Loan_Deduction = Total_Loan / Loan_Months;
			}
			else
			{
	
				cout<<"\n\n\t\t\t\t\tYou Are Already under the loan"<<endl;
			
				cout<<"Press Any Key to continue"<<endl;
				getch();
			}
		}
		void Advance_set()
		{
			if(Advance == 0)
			{

				cout<<"\n\t\t\t\t\tEnter the amount of advance : ";
				cin>>Advance;
			}
			else
			{
	
				cout<<"\t\t\t\t\tYou already take an advance ";
		
				cout<<"Press Any Key to continue"<<endl;
				getch();
			}
		}
		void Get_Salary_Info()
			{
				char check;
				Re:
	
				cout<<"\n\n\t\t\t\t\tDay Attended (out of 30) : ";
				cin>>Day_Attended;
					if (Day_Attended>30 && Day_Attended<0)
						{
				
							cout<<"Invalidc Entry";
							goto Re;
						}
	
				cout<<"\t\t\t\t\tHR_charges : ";
				cin>>HR_Charges;
			
				Bonus:
	
				cout<<"\t\t\t\t\tAny Bonus (Y/N)";
				cin>>check;
					if(check=='y' || check=='Y')
						{
			
							cout<<"\t\t\t\t\tBonus : ";
							cin>>Bonus;
						}
					else if (check=='n' || check=='N')
						{
							Bonus=0;
						}
					else
						{
	
							cout<<"\t\t\t\t\tINVALID SELECTION"<<endl;
							goto Bonus;
						}
			}
	
		string HR_number()
			{
				HR_Number= "3049117372";
				return HR_Number;
			}
		
		double Salary_Calculated(long sal)
			{
				Total_Salary=sal*Day_Attended;
				Total_Salary-=HR_Charges;
				Total_Salary-=Bonus;
				Total_Salary-=Advance;
				Advance=0;
				Total_Salary-=Loan_Deduction;
				Total_Loan =-Loan_Deduction;
					if (Total_Loan==0)
					{
						Loan_Deduction=0;
					}
				return Total_Salary;
			}
};

class Manager_data : public EMPLOYEE , public Finance
{
	protected:
		double Club_charges;
	public:
		string Designation;
		long Manager_code;
	
		void Data_picking(long Code, string F_name, string L_name, int E_Age, double E_House, string E_block, string E_Town, string E_City, string E_Province , string E_CNIC, string E_phone_no, string E_Emergency, string E_Email,  int date, int month, int year, long Salary, string Desig, double T_loan, double D_loan, double Adv)
			{	
				Manager_code = Code;
				First_name = F_name;
				Last_name = L_name;
				age = E_Age;
				House_no = E_House;
				Block = E_block;
				Town = E_Town;
				City = E_City;
				Province = E_Province;
				CNIC = E_CNIC ;
				Phone_no = E_phone_no;
				Emergency_no = E_Emergency;
				Email = E_Email;
				joining_year = year;
				joining_month = month;
				joining_date = date;
				Salary_per_day = Salary;
				Designation = Desig;
				Total_Loan = T_loan;
				Loan_Deduction = D_loan;
				Advance = Adv;
			}
			
		void M_data()
			{
				
				system("cls");
				Desig.Style();
	
				cout<<"\n\n\t\t\t\tMANAGER DATA"<<endl;
	
				cout<<"\t\t\t\tFill up the details "<<endl;
        
				cout<<"\t\t\t\t\tManager_code : ";
				cin>>Manager_code;

				cin.ignore();
				EMPLOYEE::Personal_Info();
	
				system("cls");
				Desig.Style();
				EMPLOYEE::Address();
	
				system("cls");
				Desig.Style();
				EMPLOYEE::Contact_Info();
		
				system("cls");
				cin.ignore();
				Desig.Style();
			
				cout<<"\n\n\t\t\t\tCompany information"<<endl;
				EMPLOYEE::Date_Join();

				cin.ignore();
				Sal:
		
				cout<<"\t\t\t\t\tsalary per day : "<<endl;
				cin>>Salary_per_day;
					if(Salary_per_day<3000 || Salary_per_day >7000)
						{

							cout<<"Manager Salary is invlaid";
							goto Sal;
						}

				des:
				int Designation_select;
				
				cout<<"\t\t\t\t\tDesignation"<<endl;

				cout<<"\t\t\t\t\t1.HR Manager \n\t\t\t\t\t2.Staff manager \n\t\t\t\t\t3.Social Media Manager \n\t\t\t\t\t4.Head Manager \n";
				cin>>Designation_select;
					if(Designation_select==1)
						{
				
							Designation="HR_Manager";
						}
					else if (Designation_select==2)
						{
				
							Designation="Staff_Manager";
						}
					else if (Designation_select==3)
						{
				
							Designation="Social_Media Manager";
						}
					else if (Designation_select==4)
						{
							
							Designation="Head_Manager";
						}
					else 
						{
			
							cout<<"\t\t\t\t\tDesignation doesn't exist "<<endl;
							goto des;
						}
			}
		void Display_Manager()
			{
			
				cout<<"\n\n\t\t\t\t\t\tManager Record"<<endl;
	
				cout<<"\n\t\t\t\tManager code : "<<Manager_code<<endl;
			
				cout<<"\t\t\t\tFirst Name : "<<First_name<<"\t\tLast name : "<<Last_name<<endl;
				cout<<"\t\t\t\tAge : "<<age<<"\t\t\tCNIC : "<<CNIC<<endl;
				cout<<"\t\t\t\tAddress : "<<House_no<<"-"<<Block<<" , "<<Town<<" , "<<City<<" , "<<Province<<endl;
				cout<<"\t\t\t\tPhone number :   \t+92"<<Phone_no<<endl;
				cout<<"\t\t\t\tEmergency no :   \t+92"<<Emergency_no<<endl;
				cout<<"\t\t\t\tPersonal Email : \t"<<Email<<endl;
				cout<<"\t\t\t\tJoining Date :   \t"<<joining_date<<"-"<<joining_month<<"-"<<joining_year<<endl;
				cout<<"\t\t\t\tSalary_per_day : \t"<<Salary_per_day<<endl;
				cout<<"\t\t\t\tDesignation :    \t"<<Designation<<endl;
			}
	
		void Show_All_Manager()
			{
				
			cout<<"\t\t\t"<<setw(7)<<left<<Manager_code<<setw(16)<<First_name<<setw(7)<<age<<setw(3)<<"+92"<<setw(15)<<Phone_no<<setw(2)<<joining_date<<"-"<<setw(2)<<joining_month<<"-"<<setw(10)<<joining_year<<setw(13)<<Designation<<endl;				
		    }

		void Edit()
			{
				Edit_Selection:
				int Edit_Selection;
			
				cout<<"\n\n\t\t\t\t\tWhat you wana update"<<endl;
				cout<<"\t\t\t\t\t1.Phone no"<<endl;
				cout<<"\t\t\t\t\t2.Emergency No"<<endl;
				cout<<"\t\t\t\t\t3.Email"<<endl;
				cout<<"\t\t\t\t\t4.Salary"<<endl;
				cin>>Edit_Selection;
	
					if(Edit_Selection==1)
						{
							int count1=0;
							again_p:
							cout<<"\n\n\t\t\t\t\tNew Phone no : ";
							cin>>Phone_no;
								for(int i=0; Phone_no[i]!='\0'; i++)
									{
										count1+=1;
											if(!isdigit(Phone_no[i]))
												{
													cout<<"\t\t\t\t\tINVALID INPUT"<<endl;
													goto again_p;
													break;
												}
									}
								if (count1!=10)
									{
										cout<<"\t\t\t\t\tINVALID INPUT"<<endl;
										goto again_p;
									}
						}
					else if (Edit_Selection==2)
						{
							int count1=0;
							again_e:
							cout<<"\n\n\t\t\t\t\tNew Emergency no : ";
							cin>>Emergency_no;
								for(int i=0; Emergency_no[i]!='\0'; i++)
									{
										count1+=1;
											if(!isdigit(Emergency_no[i]))
												{
													cout<<"\t\t\t\t\tINVALID INPUT"<<endl;
													goto again_e;
													break;
												}
									}
								if (count1!=10)
									{
										cout<<"\t\t\t\t\tINVALID INPUT"<<endl;
										goto again_e;
									}
						}		
					else if(Edit_Selection==3)
						{
							Em:
							cout<<"\t\t\t\t\tAgain Email :";
							cin>>Email;
								if((Email[0] >= 'a' && Email[0] <= 'z') || (Email[0] >= 'A' && Email[0] <= 'Z'))
									{
									
									}
								else
									{	
										cout<<"\t\t\t\t\tINVALID EMAIL";
										goto Em;
									}
						}
					else if(Edit_Selection==4)
						{
							Sal:
							cout<<"\t\t\t\t\tsalary per day : "<<endl;
							cin>>Salary_per_day;
								if(Salary_per_day<3000 || Salary_per_day >7000)
									{
										cout<<"\t\t\t\t\tManager Salary is invlaid";
										goto Sal;
									}
						}
					else 
						{
							system("cls");
							cout<<"Invalid Input"<<endl;
							goto Edit_Selection;
						}
			}
		
		void Salary_Print()
			{
				Club:
				char club_m;
				cout<<"\n\n\t\t\t\t\tGave INFO to make a Salary Slip"<<endl;
				cout<<"\n\t\t\t\t\tClub memeber (Y/N) ";
				cin>>club_m;
					if(club_m == 'y' || club_m == 'Y')
					{
						Club_charges=2000;
					}
					else if(club_m =='n' || club_m == 'N')
					{
						Club_charges = 0;
					}
					else 
					{
						cout<<"INVALID ENTRY ";
						goto Club;
					}
				Finance::Get_Salary_Info();
			
				system("cls");
				Desig.Style();
				cout<<"\n\n\t\t\t\t\t\t\tSALARY SLIP"<<endl;
				cout<<"\n\t\t\t\tName : "<<First_name<<" "<<Last_name<<"\t\t\tMANAGER CODE : "<<Manager_code<<endl;
				cout<<"\t\t\t\tFor Any Queriy Contact HR \t\t\t +92"<<Finance::HR_number()<<endl;
				cout<<"\n\n\n\t\t\t\tSalary Decided     \t\t\t\t\t"<<Salary_per_day<<endl;
				cout<<"\t\t\t\tTotal Day Attended \t\t\t\t\t"<<Day_Attended<<endl;
				cout<<"\t\t\t\tLoan Deduction     \t\t\t\t\t"<<Loan_Deduction<<endl;
				cout<<"\t\t\t\tHR Charges         \t\t\t\t\t"<<HR_Charges<<endl;
				cout<<"\t\t\t\tClub Charges       \t\t\t\t\t"<<Club_charges<<endl;
				cout<<"\t\t\t\tAdvance            \t\t\t\t\t"<<Advance<<endl;
				cout<<"\t\t\t\tBonus              \t\t\t\t\t"<<Bonus<<endl;
				cout<<"\t\t\t\t------------------------------------------------------------"<<endl;
				cout<<"\t\t\t\tTotal Salary out   \t\t\t\t\t"<<Finance::Salary_Calculated(Salary_per_day)<<endl;
			}

		void Storing_Manager_Data()
			{
				ofstream Manager_Data("Manager.xls", ios::app);
					Manager_Data<<Manager_code<<"\t"<<First_name<<"\t"<<Last_name<<"\t"<<age<<"\t"<<House_no<<"\t"<<Block<<"\t"<<Town<<"\t"<<City<<"\t"<<Province<<"\t"<<CNIC<<"\t"<<Phone_no<<"\t"<<Emergency_no<<"\t"<<Email<<"\t"<<joining_date<<"\t"<<joining_month<<"\t"<<joining_year<<"\t"<<Salary_per_day<<"\t"<<Designation<<"\t"<<Total_Loan<<"\t"<<Loan_Deduction<<"\t"<<Advance<<endl;	
				Manager_Data.close();
			}
};

class Worker_data : public EMPLOYEE , public Finance
{
	public:
		string worker_department;
		string Shift;
		long worker_code;
	
		void Data_picking(long Code, string F_name, string L_name, int E_Age, double E_House, string E_block, string E_Town, string E_City, string E_Province , string E_CNIC, string E_phone_no, string E_Emergency, string E_Email,  int date, int month, int year, long Salary,string Depart, string Shi, double T_loan, double D_loan, double Adv)
			{
				worker_code = Code;
				First_name = F_name;
				Last_name = L_name;
				age = E_Age;
				House_no = E_House;
				Block = E_block;
				Town = E_Town;
				City = E_City;
				Province = E_Province;
				CNIC = E_CNIC ;
				Phone_no = E_phone_no;
				Emergency_no = E_Emergency;
				Email = E_Email;
				joining_year = year;
				joining_month = month;
				joining_date = date;
				Salary_per_day = Salary;
				worker_department = Depart;
				Shift = Shi;
				Total_Loan = T_loan;
				Loan_Deduction = D_loan;
				Advance = Adv;
			}
	
		void W_data()
			{
				system("cls");
				Desig.Style();
				cout<<"\t\t\t\t\tWORKER DATA"<<endl;
				cout<<"\t\t\t\t\tFill up the details "<<endl;
				cout<<"\t\t\t\t\tWorker code : ";
				cin>>worker_code;
				
				cin.ignore();
				EMPLOYEE::Personal_Info();
	
				system("cls");
				Desig.Style();
				EMPLOYEE::Address();
	
				system("cls");
				Desig.Style();
				EMPLOYEE::Contact_Info();
	
				system("cls");
				Desig.Style();
				cout<<"\t\t\t\t\tCompany information"<<endl;
				EMPLOYEE::Date_Join();
				cin.ignore();
				
				Sal:
				cout<<"\t\t\t\t\tsalary per day : ";
				cin>>Salary_per_day;
					if(Salary_per_day<800 || Salary_per_day >2500)
						{
							cout<<"\t\t\t\t\tWorker Salary is invlaid";
							goto Sal;
						}
						
				int department_select;
				Dep:
				cout<<"\t\t\t\t\tWorker Department "<<endl;
				cout<<"\t\t\t\t\t1. Cutting\n\t\t\t\t\t2.Stiching\n\t\t\t\t\t3.Quality\n\t\t\t\t\t4.Packing\n\t\t\t\t\t5.Loading\n\t\t\t\t\t6.Driver"<<endl;
				cout<<"\t\t\t\t\t";
				cin>>department_select;
					if (department_select == 1)
						{
							worker_department = "Cutting";
						}
					else if (department_select == 2)
						{
							worker_department = "Stiching";
						}
					else if (department_select == 3)
						{
							worker_department = "Quality";
						}
					else if (department_select == 4)
						{
							worker_department = "Packing";
						}
					else if (department_select == 5)
						{
							worker_department = "Loading" ;
						}
					else if (department_select == 6)
						{
							worker_department = "Driver";
						}
					else 
						{
							cout<<"\t\t\t\t\tINVALID SELECTION";
							goto Dep;
						}
	
				int shift_select;
				Sh:
				cout<<"\t\t\t\t\tSelect Shift"<<endl;
				cout<<"\n\t\t\t\t\t1.Morning\n\t\t\t\t\t2.Evening\n\t\t\t\t\t3.Night"<<endl;
				cout<<"\t\t\t\t\t";
				cin>>shift_select;
					if(shift_select==1)
						{
							Shift="Morning";
						}
					else if(shift_select==2)
						{
							Shift="Evening";
						}
					else if(shift_select==3)
						{
							Shift="Night";
						}
					else
						{
							cout<<"\t\t\t\t\tINVALID ENTRY";
							goto Sh;
						}
			}

		void Display_Worker()
			{
			cout<<"\n\n\t\t\t\t\t\tWorker Record"<<endl;
				cout<<"\n\t\t\t\tWorker code : "<<worker_code<<endl;
				cout<<"\t\t\t\tFirst Name : "<<First_name<<"\t\tLast name : "<<Last_name<<endl;
				cout<<"\t\t\t\tAge : "<<age<<"\t\t\tCNIC : "<<CNIC<<endl;
				cout<<"\t\t\t\tAddress : "<<House_no<<"-"<<Block<<" , "<<Town<<" , "<<City<<" , "<<Province<<endl;
				cout<<"\t\t\t\tPhone number :   \t+92"<<Phone_no<<endl;
				cout<<"\t\t\t\tEmergency no :   \t+92"<<Emergency_no<<endl;
				cout<<"\t\t\t\tPersonal Email : \t"<<Email<<endl;
				cout<<"\t\t\t\tJoining Date :   \t"<<joining_date<<"-"<<joining_month<<"-"<<joining_year<<endl;
				cout<<"\t\t\t\tSalary_per_day : \t"<<Salary_per_day<<endl;
				cout<<"\t\t\t\tDepartment :     \t"<<worker_department<<endl;
				cout<<"\t\t\t\tShift Timing :   \t"<<Shift<<endl;
			}

		void Show_All_Worker()
			{
				cout<<"\t\t\t"<<worker_code<<"  "<<First_name<<" "<<Last_name<<"   "<<age<<"      +92"<<Phone_no<<"     "<<joining_date<<"-"<<joining_month<<"-"<<joining_year<<"        "<<worker_department<<"      "<<Shift<<endl;
			}
		
		void Edit()
			{
				Edit_Selection:
				int Edit_Selection;
				cout<<"\n\n\t\t\t\t\tWhat you want to update"<<endl;
				cout<<"\t\t\t\t\t1.Phone no"<<endl;
				cout<<"\t\t\t\t\t2.Emergency No"<<endl;
				cout<<"\t\t\t\t\t3.Email"<<endl;
				cout<<"\t\t\t\t\t4.Salary"<<endl;
				cin>>Edit_Selection;
	
					if(Edit_Selection==1)
						{
							int count1=0;
							again_p:
							cout<<"\n\n\t\t\t\t\tNew Phone no : ";
							cin>>Phone_no;
								for(int i=0; Phone_no[i]!='\0'; i++)
									{
										count1+=1;
											if(!isdigit(Phone_no[i]))
												{
													cout<<"\t\t\t\t\tINVALID INPUT"<<endl;
													goto again_p;
													break;
												}
									}
								if (count1!=10)
									{
										cout<<"\t\t\t\t\tINVALID INPUT"<<endl;
										goto again_p;
									}
						}
					else if (Edit_Selection==2)
						{
							int count1=0;
							again_e:
							cout<<"\n\n\t\t\t\t\tNew Emergency no : ";
							cin>>Emergency_no;
								for(int i=0; Emergency_no[i]!='\0'; i++)
									{
										count1+=1;
											if(!isdigit(Emergency_no[i]))
												{
													cout<<"\t\t\t\t\tINVALID INPUT"<<endl;
													goto again_e;
													break;
												}
									}
								if (count1!=10)
									{
										cout<<"\t\t\t\t\tINVALID INPUT"<<endl;
										goto again_e;
									}
						}		
					else if(Edit_Selection==3)
						{
							Em:
							cout<<"\t\t\t\t\tAgain Email :";
							cin>>Email;
								if((Email[0] >= 'a' && Email[0] <= 'z') || (Email[0] >= 'A' && Email[0] <= 'Z'))
									{
									
									}
								else
									{	
										cout<<"\t\t\t\t\tINVALID EMAIL";
										goto Em;
									}
						}
					else if(Edit_Selection==4)
						{
							Sal:
							cout<<"\t\t\t\t\tsalary per day : "<<endl;
							cin>>Salary_per_day;
								if(Salary_per_day<800 || Salary_per_day >2500)
									{
										cout<<"\t\t\t\t\tWorker Salary is invlaid"<<endl;
										goto Sal;
									}
						}
					else 
						{
							system("cls");
							cout<<"\t\t\t\t\tInvalid Input"<<endl;
							goto Edit_Selection;
						}
			}
		void Salary_Print()
			{
				system("cls");
				Desig.Style();
				cout<<"\t\t\t\t\tGave INFO to make a Salary Slip"<<endl;
				Finance::Get_Salary_Info();
		
				system("cls");
				Desig.Style();
				cout<<"\n\n\t\t\t\t\t\tSALARY SLIP"<<endl;
				cout<<"\t\t\t\tName : "<<First_name<<" "<<Last_name<<"\t\t\tWORKER CODE : "<<worker_code<<endl;
				cout<<"\t\t\t\tFor Any Queriy Contact HR \t\t\t"<<Finance::HR_number()<<endl;
				cout<<"\n\t\t\t\tSalary Decided     \t\t\t\t\t"<<Salary_per_day<<endl;
				cout<<"\t\t\t\tTotal Day Attended \t\t\t\t\t"<<Day_Attended<<endl;
				cout<<"\t\t\t\tLoan Deduction     \t\t\t\t\t"<<Loan_Deduction<<endl;
				cout<<"\t\t\t\tHR Charges         \t\t\t\t\t"<<HR_Charges<<endl;
				cout<<"\t\t\t\tAdvance            \t\t\t\t\t"<<Advance<<endl;
				cout<<"\t\t\t\tBonus              \t\t\t\t\t"<<Bonus<<endl;
				cout<<"\t\t\t\t------------------------------------------------------------"<<endl;
				cout<<"\t\t\t\tTotal Salary out   \t\t\t\t\t"<<Finance::Salary_Calculated(Salary_per_day)<<endl;
			}
			
		void Storing_Worker_Data()
			{
				ofstream Worker_Data("Worker.xls", ios::app);
	
					Worker_Data<<worker_code<<"\t"<<First_name<<"\t"<<Last_name<<"\t"<<age<<"\t"<<House_no<<"\t"<<Block<<"\t"<<Town<<"\t"<<City<<"\t"<<Province<<"\t"<<CNIC<<"\t"<<Phone_no<<"\t"<<Emergency_no<<"\t"<<Email<<"\t"<<joining_date<<"\t"<<joining_month<<"\t"<<joining_year<<"\t"<<Salary_per_day<<"\t"<<worker_department<<"\t"<<Shift<<"\t"<<Total_Loan<<"\t"<<Loan_Deduction<<"\t"<<Advance<<endl;
		
				Worker_Data.close();
			}
	
};

class main_menu
{
	private:
		string worker_department , Shift;
		long worker_code , Manager_code,  Salary_per_day;
		string First_name , Last_name;
		double House_no;
		string Block, Town ,City , Province;
		string CNIC ,Phone_no , Emergency_no ,Email , Designation;
		int joining_year, joining_month , joining_date, age ;
		double Total_Loan, Loan_Deduction, Advance;
		
		Manager_data SCB_M[10];	
		Worker_data SCB_W[1000];
	
		Store_List S_L;
	
		int choice;
	
	public:
		main_menu()
		{	
			choice=0;
		}

		void Selection_1()
		{
			system("cls");
			
			R_s:
			Desig.Style();
			int Record_selection;
			cout<<"\n\n\t\t\t\tWhich one you want to add"<<endl;
			cout<<"\n\t\t\t\t\t1. Manager"<<endl;
			cout<<"\t\t\t\t\t2. Worker "<<endl;
			cin>>Record_selection;
			if(Record_selection==1)
				{
					Manager_max++;
					SCB_M[Manager_max-1].M_data();
				}
			else if (Record_selection==2)
				{
					Worker_max++;
					SCB_W[Worker_max-1].W_data();
				}
			else
				{
					system("cls");
					cout<<"	Invalid Selection"<<endl;
					goto R_s; 
				}
		}

		void Selection_2()
		{
			system("cls");
			dis:
			Desig.Style();
			int select_disp;
			cout<<"\t\t\t\t\tSelect your choice"<<endl;
			cout<<"\t\t\t\t\t1.Show manager record"<<endl;
			cout<<"\t\t\t\t\t2.show worker record"<<endl;
			cin>>select_disp;

				if(select_disp==1)
					{
						M_dis:
						system("cls");
						Desig.Style();
						int Sel_dis;
						cout<<"\t\t\t\t\tChoice"<<endl;
						cout<<"\t\t\t\t\t1.Show all record"<<endl;
						cout<<"\t\t\t\t\t2.Found by ID"<<endl;
						cout<<"\t\t\t\t\t3.Designation"<<endl;
						cin>>Sel_dis;
						
							if(Sel_dis==1)
								{
									system("cls");
									Desig.Style();
									cout<<"\n\t\t\t\t\t\tManager Records"<<endl;
									cout<<"\n\t\t\tID"<<"     "<<"Name"<<"\t       "<<"age"<<"     "<<"Phone no"<<"        "<<" joining Date"<<"    "<<"Designation"<<endl;
									cout<<"\t\t\t============================================================================="<<endl;
										for(int i=0; i<Manager_max;i++)
											{
												SCB_M[i].Show_All_Manager();
											}
									cout<<"\nPress Any key to continue";
									getch();
								}
							else if(Sel_dis==2)
								{
									
									system("cls");
									Check_MR:
									Desig.Style();
									int counter;
									long Found_ID;
									cout<<"\t\t\t\t\tEnter Search ID : "; 
									cin>>Found_ID;
									counter=0;
										for(int i=0; i<Manager_max; i++)
											{
												if (Found_ID==SCB_M[i].Manager_code)
													{
														counter++;
														SCB_M[i].Display_Manager();
														break;
													}
											}
										if (counter==0)
											{
												system("cls");
												cout<<"\t\t\t\t\tNo Record Found"<<endl;
												goto Check_MR;
											}
										cout<<"\nPress Any key to continue";
										getch();
								}
							else if(Sel_dis==3)
								{
									system("cls");
									Check_DMR:
									Desig.Style();
									int counter;
									int Check_Des;
									string Found_Des;
									cout<<"\t\t\t\t\tEnter Designation : "<<endl;
									cout<<"\t\t\t\t\t1.HR Manager \n\t\t\t\t\t2.Staff manager \n\t\t\t\t\t3.Social Media Manager \n\t\t\t\t\t4.Head Manager \n"; 
									cin>>Check_Des;
									if(Check_Des==1){Found_Des="HR_Manager";}
									else if (Check_Des==2){Found_Des="Staff_manager";}
									else if (Check_Des==3){Found_Des="Social_Media_Manager";}
									else if (Check_Des==4){Found_Des="Head_Manager";}
									else 				  {system("cls"); goto Check_DMR;}
									counter=0;
									system("cls");
									Desig.Style();
									cout<<"\n\t\t\t\t\t\tManager Records"<<endl;
									cout<<"\n\t\t\tID"<<"     "<<"Name"<<"\t       "<<"age"<<"     "<<"Phone no"<<"        "<<" joining Date"<<"    "<<"Designation"<<endl;
									cout<<"\t\t\t============================================================================="<<endl;
										for(int i=0; i<Manager_max;i++)
											{
												if(Found_Des==SCB_M[i].Designation)
												{
													counter++;
													SCB_M[i].Show_All_Manager();
												}
											}
									if (counter==0)
									{
										system("cls");
										cout<<"No Manager of this designation"<<endl;
										goto Check_DMR;
									}
									cout<<"\nPress Any key to continue";
									getch();
								}
							else
								{
									cout<<"\t\t\t\t\tInvalid Entry"<<endl;
									goto M_dis;
								}
					}
				else if(select_disp==2)
					{
						system("cls");
						W_dis:
						Desig.Style();
						int Sel_dis;
						cout<<"\t\t\t\t\tChoice"<<endl;
						cout<<"\t\t\t\t\t1.Show all record"<<endl;
						cout<<"\t\t\t\t\t2.Found by ID"<<endl;
						cout<<"\t\t\t\t\t3.Shift"<<endl;
						cout<<"\t\t\t\t\t4.Department"<<endl;
						cin>>Sel_dis;
						
							if(Sel_dis==1)
								{
									system("cls");
									Desig.Style();
									cout<<"\n\t\t\t\t\t\tWorker Records"<<endl;
									cout<<"\n\t\t\tID"<<"     "<<"Name"<<"\t       "<<"age"<<"     "<<"Phone no"<<"        "<<" joining Date"<<"    "<<"Department"<<"    "<<"Shift"<<endl;
									cout<<"\t\t\t==================================================================================="<<endl;
										for(int i=0; i<Worker_max;i++)
											{
												SCB_W[i].Show_All_Worker();
											}
									cout<<"\nPress Any key to continue";
									getch();
								}
							else if(Sel_dis==2)
								{
									system("cls");
									Check_WR:
									int counter;
									long Found_ID;
									Desig.Style();
									cout<<"\t\t\t\t\tEnter Search ID : ";
									cin>>Found_ID;
									counter=0;
										for(int i=0; i<Worker_max; i++)
											{
												if (Found_ID==SCB_W[i].worker_code)
													{
														counter++;
														system("cls");
														Desig.Style();
														SCB_W[i].Display_Worker();
													}
											}
											if (counter==0)
											{
												system("cls");
												cout<<"\t\t\t\t\tNo Record Found"<<endl;
												goto Check_WR;
											}
											cout<<"\nPress Any key to continue";
											getch();
								}
							else if(Sel_dis==3)
								{
									system("cls");
									Check_SER:
									Desig.Style();
									int counter;
									int Check_Shi;
									string Found_Shi;
									cout<<"\t\t\t\t\tEnter Shift : "<<endl;
									cout<<"\n\t\t\t\t\t1.Morning\n\t\t\t\t\t2.Evening\n\t\t\t\t\t3.Night"<<endl;
									cin>>Check_Shi;
									if(Check_Shi==1){Found_Shi="Morning";}
									else if (Check_Shi==2){Found_Shi="Evening";}
									else if (Check_Shi==3){Found_Shi="Night";}
									else 				  {system("cls"); goto Check_DER;}
									counter=0;
									system("cls");
									Desig.Style();
									cout<<"\n\t\t\t\t\t\tWorker Records"<<endl;
									cout<<"\n\t\t\tID"<<"     "<<"Name"<<"\t       "<<"age"<<"\t     "<<"Phone no"<<"\t        "<<" joining Date"<<"\t        "<<"Department"<<"\t        "<<"Shift"<<endl;
									cout<<"\t\t\t==================================================================================="<<endl;
										for(int i=0; i<Worker_max;i++)
											{
												if(Found_Shi==SCB_W[i].Shift)
												{
													counter++;
													SCB_W[i].Show_All_Worker();
												}
											}
									if (counter==0)
									{
										system("cls");
										cout<<"No Worker of this Shift"<<endl;
										goto Check_SER;
									}
									cout<<"\nPress Any key to continue";
									getch();
								}
							else if(Sel_dis==4)
								{
									system("cls");
									Check_DER:
									Desig.Style();
									int counter;
									int Check_Dep;
									string Found_Dep;
									cout<<"\t\t\t\t\tEnter Department : "<<endl;
									cout<<"\t\t\t\t\t1. Cutting\n\t\t\t\t\t2.Stiching\n\t\t\t\t\t3.Quality\n\t\t\t\t\t4.Packing\n\t\t\t\t\t5.Loading\n\t\t\t\t\t6.Driver"<<endl;
									cin>>Check_Dep;
									if(Check_Dep==1){Found_Dep="Cutting";}
									else if (Check_Dep==2){Found_Dep="Stiching";}
									else if (Check_Dep==3){Found_Dep="Quality";}
									else if (Check_Dep==4){Found_Dep="Packing";}
									else if (Check_Dep==5){Found_Dep="Loading";}
									else if (Check_Dep==6){Found_Dep="Driver";}
									else 				  {system("cls"); goto Check_DER;}
									counter=0;
									system("cls");
									Desig.Style();
									cout<<"\n\t\t\t\t\t\tWorker Records"<<endl;
									cout<<"\n\t\t\tID"<<"     "<<"Name"<<"\t       "<<"age"<<"     "<<"Phone no"<<"        "<<" joining Date"<<"    "<<"Department"<<"    "<<"Shift"<<endl;
									cout<<"\t\t\t==================================================================================="<<endl;
										for(int i=0; i<Worker_max;i++)
											{
												if(Found_Dep==SCB_W[i].worker_department)
												{
													counter++;
													SCB_W[i].Show_All_Worker();
												}
											}
									if (counter==0)
									{
										system("cls");
										cout<<"No Worker of this Shift"<<endl;
										goto Check_DER;
									}
									cout<<"\nPress Any key to continue";
									getch();
								}
							else
								{
									system("cls");
									cout<<"\t\t\t\t\tInvalid Entry"<<endl;
									goto W_dis;
								}
					}
				else
					{
						system("cls");
						cout<<"\t\t\t\t\tInvalid input"<<endl;
						goto dis;
					}
		}

		void Selection_3()
		{
			system("cls");
			M_s:
			Desig.Style();
			int M_selection;
			cout<<"\t\t\t\t\tEnter your choice "<<endl;
			cout<<"\t\t\t\t\t1.Edit record"<<endl;
			cout<<"\t\t\t\t\t2.Delete record"<<endl;
			cin>>M_selection;
			
			if(M_selection==1)
				{
					long Found_id;
					int counter;
					system("cls");
					E_s:
					Desig.Style();
					int E_selection;
					cout<<"\t\t\t\t\tEnter your choice "<<endl;
					cout<<"\t\t\t\t\t1.Manager Edit"<<endl;
					cout<<"\t\t\t\t\t2.Worker Edit "<<endl;
					cin>>E_selection;
						if(E_selection==1)
							{
								system("cls");
								ME_I:
								Desig.Style();
								cout<<"\t\t\t\t\tEnter ID : ";
								cin>>Found_id;
								counter=0;
									for(int i=0; i<Manager_max; i++)
										{
											if (Found_id==SCB_M[i].Manager_code)
												{
													SCB_M[i].Display_Manager();
													counter++;
													SCB_M[i].Edit();
													break;
												}
										}
									if (counter==0)
										{
											cout<<"\t\t\t\t\tNo Record Found"<<endl;
											goto ME_I;
										}
									system("cls");
									Desig.Style();	
									cout<<"\n\t\t\t\t\tManager_Data updated"<<endl;
									cout<<"\n\t\t\t\t\tPress Any key to continue";
									getch();
							}
						else if (E_selection==2)
							{
								system("cls");
								WE_I:
								Desig.Style();
								cout<<"\t\t\t\t\tEnter ID : ";
								cin>>Found_id;
								counter=0;
								for(int i=0; i<Worker_max; i++)
									{
										if (Found_id==SCB_W[i].worker_code)
											{
												SCB_W[i].Display_Worker();
												counter++;
												SCB_W[i].Edit();
											}
									}
								if (counter==0)
									{
										cout<<"\t\t\t\t\tNo Record Found"<<endl;
										goto WE_I;
									}
								system("cls");
								Desig.Style();	
								cout<<"\n\t\t\t\t\tManager_Data updated"<<endl;
								cout<<"\n\t\t\t\t\tPress Any key to continue";
								getch();
							}
						else
							{
								system("cls");
								cout<<"\t\t\t\t\tInvalid Input"<<endl;
								goto E_s;
							}
				}
			else if(M_selection==2)
				{
					int counter;
					long Found_ID;
					system("cls");
					D_s:
					Desig.Style();
					int D_selection;
					cout<<"\t\t\t\t\tEnter your choice "<<endl;
					cout<<"\t\t\t\t\t1.Manager Delete"<<endl;
					cout<<"\t\t\t\t\t2.Worker Delete"<<endl;
					cin>>D_selection;
	
						if(D_selection==1)
							{
								system("cls");
								MD_I:
								Desig.Style();
								counter=0;
								cout<<"\t\t\t\t\tEnter ID : ";
								cin>>Found_ID;
									for(int i=0; i<Manager_max; i++)
										{
											if(Found_ID==SCB_M[i].Manager_code)
												{
													counter++;
													for(int j=i; i<Manager_max; i++)
													{
														SCB_M[j] = SCB_M[j+1];
													}
													Manager_max--;
													break;
												}
										}
									if(counter==0)
										{
											system("cls");
											cout<<"\t\t\t\t\tNo Record Found"<<endl;
											goto MD_I;
										}
									system("cls");
									Desig.Style();
									cout<<"\n\n\t\t\t\t\tManager_Data Deleted successfully"<<endl;
									cout<<"\n\t\t\t\t\tPress enter to continue";
									getch();
							}
						else if (D_selection==2)
							{
								system("cls");
								WD_I:
								Desig.Style();
								counter=0;
								cout<<"\t\t\t\t\tEnter ID : ";
								cin>>Found_ID;
								for(int i=0; i<Worker_max; i++)
									{
										if(Found_ID==SCB_W[i].worker_code)
											{
												counter++;
												for(int j=i; i<Worker_max; i++)
													{
														SCB_W[j] = SCB_W[j+1];
													}
												Worker_max--;
												break;
											}
									}
								if(counter==0)
									{
										system("cls");
										cout<<"\t\t\t\t\tNo Record Found"<<endl;
										goto WD_I;
									}
								system("cls");
								Desig.Style();
								cout<<"\n\n\t\t\t\t\tWorker_Data Deleted successfully"<<endl;
								cout<<"\n\t\t\t\t\tPress enter to continue";
								getch();
							}
						else
							{
								system("cls");
								cout<<"\t\t\t\t\tInvalid Input"<<endl;
								goto D_s;
							}
				}
			else
				{
					system("cls");
					cout<<"\t\t\t\t\tInvalid Selection"<<endl;
					goto M_s;
				}
		}

		void Selection_4()
		{
			long Found_id;
			int select;
			int found;
			int counter;
			system("cls");
			Re_F:
			Desig.Style();
			cout<<"\t\t\t\t\tEnter your choice"<<endl;
			cout<<"\t\t\t\t\t1. Manager Finance"<<endl;
			cout<<"\t\t\t\t\t2. Worker Finance"<<endl;
			cin>>select;
			if (select==1)
			{
				system("cls");
				Desig.Style();
				cout<<"\t\t\t\t\tEnter Your Choice "<<endl;
				cout<<"\t\t\t\t\t1. Take Loan "<<endl;
				cout<<"\t\t\t\t\t2. Advance "<<endl;
				cout<<"\t\t\t\t\t3. Salary Slip"<<endl;
				cin>>select;
				system("cls");
				M_F:
				Desig.Style();
				cout<<"\t\t\t\t\tEnter Manager ID : ";
				cin>>Found_id;
				counter=0;
				for(int i=0; i<Manager_max; i++)
				{
					if(Found_id==SCB_M[i].Manager_code)
					{
						counter++;
						found=i;
						break;	
					}
				}
				if(counter==0)
				{
					system("cls");
					cout<<"\t\t\t\t\tNo Record Found "<<endl;
					goto M_F;
				}
					if(select == 1)
					{
						system("cls");
						Desig.Style();
						SCB_M[found].Loan_Facility();
					}
					else if (select ==2)
					{
						system("cls");
						Desig.Style();
						SCB_M[found].Advance_set();
					}
					else if (select ==3)
					{
						system("cls");
						Desig.Style();
						SCB_M[found].Salary_Print();
						cout<<"Press Any Key to continue"<<endl;
						getch();				
					}
			}
			else if(select == 2)
			{
				system("cls");
				Desig.Style();
				cout<<"\t\t\t\t\tEnter Your Choice "<<endl;
				cout<<"\t\t\t\t\t1. Take Loan "<<endl;
				cout<<"\t\t\t\t\t2. Advance "<<endl;
				cout<<"\t\t\t\t\t3. Salary Slip"<<endl;
				cin>>select;
				system("cls");
				E_F:
				Desig.Style();
				cout<<"\t\t\t\t\tEnter Worker ID : ";
				cin>>Found_id;
				counter=0;
				for(int i=0; i<Worker_max; i++)
				{
					if(Found_id==SCB_W[i].worker_code)
					{
						counter++;
						found=i;
						break;	
					}
				}
				if(counter==0)
				{
					cout<<"\t\t\t\t\tNo Record Found "<<endl;
					goto E_F;
				}
					if(select == 1)
					{
						system("cls");
						Desig.Style();
						SCB_W[found].Loan_Facility();
					}
					else if (select ==2)
					{
						system("cls");
						Desig.Style();
						SCB_W[found].Advance_set();
					}
					else if (select ==3)
					{
						system("cls");
						Desig.Style();
						SCB_W[found].Salary_Print();
						cout<<"Press Any Key to continue"<<endl;
						getch();				
					}
			}
			else 
			{
				system("cls");
				cout<<"\t\t\t\t\tInvalid option"<<endl;
				goto Re_F;
			}
			
		}
	
		void Selection_5()
		{
			S_L.Get_Manager_list();
			S_L.Get_Worker_list();
	
			ofstream Manager_Dat("Manager.xls", ios::out  |  ios::trunc);
				for(int i=0; i<Manager_max; i++)
				{
					SCB_M[i].Storing_Manager_Data();
				}
			Manager_Dat.close();
	
			ofstream Worker_Dat("Worker.xls", ios::out  |  ios::trunc);
				for(int i=0; i<Worker_max; i++)
				{
					SCB_W[i].Storing_Worker_Data();
				}
			Worker_Dat.close();
		}	
	
		void Data_picking()
		{
		
			S_L.Put_Manager_list();
			S_L.Put_Worker_list();
	
			ifstream Manager_data("Manager.xls", ios::in);
			Manager_data>>Manager_code>>First_name>>Last_name>>age>>House_no>>Block>>Town>>City>>Province>>CNIC>>Phone_no>>Emergency_no>>Email>>joining_date>>joining_month>>joining_year>>Salary_per_day>>Designation>>Total_Loan>>Loan_Deduction>>Advance;	
				for(int i=0; i<Manager_max; i++)
					{
						SCB_M[i].Data_picking(Manager_code,First_name,Last_name,age,House_no,Block,Town,City,Province,CNIC,Phone_no,Emergency_no,Email,joining_date,joining_month,joining_year,Salary_per_day,Designation,Total_Loan,Loan_Deduction,Advance);
						Manager_data>>Manager_code>>First_name>>Last_name>>age>>House_no>>Block>>Town>>City>>Province>>CNIC>>Phone_no>>Emergency_no>>Email>>joining_date>>joining_month>>joining_year>>Salary_per_day>>Designation>>Total_Loan>>Loan_Deduction>>Advance;	
						
					}
			Manager_data.close();

		
			ifstream Worker_data("Worker.xls", ios::in);
			Worker_data>>worker_code>>First_name>>Last_name>>age>>House_no>>Block>>Town>>City>>Province>>CNIC>>Phone_no>>Emergency_no>>Email>>joining_date>>joining_month>>joining_year>>Salary_per_day>>worker_department>>Shift>>Total_Loan>>Loan_Deduction>>Advance;
			for(int i=0; i<Worker_max; i++)
					{
						SCB_W[i].Data_picking(worker_code,First_name,Last_name,age,House_no,Block,Town,City,Province,CNIC,Phone_no,Emergency_no,Email,joining_date,joining_month,joining_year,Salary_per_day,worker_department,Shift,Total_Loan,Loan_Deduction,Advance);
						Worker_data>>worker_code>>First_name>>Last_name>>age>>House_no>>Block>>Town>>City>>Province>>CNIC>>Phone_no>>Emergency_no>>Email>>joining_date>>joining_month>>joining_year>>Salary_per_day>>worker_department>>Shift>>Total_Loan>>Loan_Deduction>>Advance;
					}
			Worker_data.close();
		}
		void menu()
		{
			Data_picking();
			
			login_try log;
			log.login_attempt();
	
			Desig.Style();
			cout<<"\n\n\t\t\t\tlogin attempt successfull"<<endl;
			cout<<"\n\t\t\t\t\twelcome back"<<endl;
			cout<<"\t\t\t\t\tLoading";
			Desig.Loading_Style();
			system("cls");
	
				for	(int i=0; i<1000 ; i++)
					{
						system("cls");
						Desig.Style();
						cout<<"\n\n \t\t\t\tselect any one option to continue "<<endl;
						cout<<"\n\t\t\t\t\t1.New epmployee"<<endl;
						cout<<"\t\t\t\t\t2.Dispaly Employee"<<endl;
						cout<<"\t\t\t\t\t3.Modify Record"<<endl;
						cout<<"\t\t\t\t\t4.Finance Managment"<<endl;
						cout<<"\t\t\t\t\t5.Exit"<<endl;
						cin>>choice;
							if (choice==1)
								{
									Selection_1();
								}
							else if(choice==2)
								{
									Selection_2();
								}
							else if(choice==3)
								{
									Selection_3();
								}
							else if(choice==4)
								{
									Selection_4();
								}
							else if(choice==5)
								{	
									Selection_5();
									break;
								}
							else
								{
									system("cls");
									cout<<"invalid selection"<<endl;
								}
					}
		}

};

int main()
{
	main_menu men;
	men.menu();
}

